read LINE
X=$(echo $LINE|cut -d ' ' -f 2)
Y=$(echo $LINE|cut -d ' ' -f 3)
echo "Chat $X $Y"
