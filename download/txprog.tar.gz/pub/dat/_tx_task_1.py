line = raw_input()
arr = line.split(' ')
print 'Chat %d %d' % (int(arr[1]), int(arr[2]))
