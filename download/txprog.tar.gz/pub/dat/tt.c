#include <stdio.h>
int main(int argc, char * argv[])
{
int a = 1;
printf("Input a: ");
scanf("%d", &a);

for(int i=0; i<a; i++) {
	printf("i: %d ", i);
	for(int j=0; j<i; j++) {
		printf("*");
	}
		printf("\n");
}
printf("end\n");


return 0;
}

