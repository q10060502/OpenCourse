#include <stdio.h>
int main(int argc, char * argv[])
{
	//Lv3 How Many Coins per Moving
	int coin_num;
	int n = 0;
	scanf("%*d %*d");
	scanf("%d", &coin_num);
	printf("Move Right\n");
	n++;
	printf("Move Down\n");
	n++;
	printf("Move Left\n");
	n++;
	printf("Move Up\n");
	n++;
	printf("Move Up\n");
	n++;
	printf("Chat %.2f\n", (float)coin_num / n );
	return 0;
}
