import java.util.Scanner;

public class _tx_task_1 {
	public static void main(String[] args) {
		String c;
		int x, y;
		Scanner scn = new Scanner(System.in);
		c = scn.next();
		x = scn.nextInt();
		y = scn.nextInt();
		System.out.printf("Chat %d %d", x, y);
	}
}
