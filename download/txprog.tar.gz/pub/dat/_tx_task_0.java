public class _tx_task_0 {
	public static void main(String[] args) {
		System.out.println("Chat Hello World");
	}
}
