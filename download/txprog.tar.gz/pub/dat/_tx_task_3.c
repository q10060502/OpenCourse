#include <stdio.h>
int main(int argc, char * argv[])
{
	//Lv4 Watch Out for Fire
	int hero_x, hero_y;
	int coin_num;
	int coin_x, coin_y;
	int fire_num;
	scanf("%d %d", &hero_x, &hero_y);
	scanf("%d", &coin_num);
	scanf("%d %d", &coin_x, &coin_y);
	scanf("%d", &fire_num);
	if(coin_x == hero_x && coin_y < hero_y) {
		printf("Move Up\n");
	} else if(coin_x == hero_x && coin_y > hero_y) {
		printf("Move Down\n");
	} else if(coin_x < hero_x && coin_y == hero_y) {
		printf("Move Left\n");
	} else if(coin_x > hero_x && coin_y == hero_y) {
		printf("Move Right\n");
	} else {
		printf("Rest\n");
	}
	printf("Chat %d\n", fire_num);
	
	return 0;
}
