#include <stdio.h>
int main(int argc, char * argv[])
{
	//Lv1 Hello World
	printf("Chat Hello World\n");
	return 0;
}
