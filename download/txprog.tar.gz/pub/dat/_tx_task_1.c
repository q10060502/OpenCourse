#include <stdio.h>
int main(int argc, char * argv[])
{
	//Lv2 Where am I
	int hero_x, hero_y;
	scanf("%* %d %d", &hero_x, &hero_y);
	printf("Chat %d %d\n", hero_x, hero_y);
	return 0;
}
