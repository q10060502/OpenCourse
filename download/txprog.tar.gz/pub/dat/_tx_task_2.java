public class _tx_task_2 {
	public static void main(String[] args) {
		System.out.println("Say Hello World");
	}
}
