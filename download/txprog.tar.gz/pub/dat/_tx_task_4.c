#include <stdio.h>
int main(int argc, char * argv[])
{
	//Lv5 Chop Ogres 
	int hero_x, hero_y;
	int coin_num;
	int coin_x, coin_y;
	int fire_num;
	int fire_x, fire_y;
	int ogre_num;
	int ogre_x, ogre_y;
	scanf("%d %d", &hero_x, &hero_y);
	scanf("%d", &coin_num);
	scanf("%d %d", &coin_x, &coin_y);
	scanf("%d", &fire_num);
	scanf("%d %d", &fire_x, &fire_y);
	scanf("%d", &ogre_num);
	scanf("%d %d", &ogre_x, &ogre_y);

	for(int i = 0; i < ogre_num; i++) {
		printf("Move Right\n");
		printf("Chop Right\n");
		printf("Move Down\n");
	}

	for(int i = 0; i < coin_num; i++) {
		printf("Move Left\n");
		printf("Move Up\n");
	}
	printf("Chat %d\n", ogre_num);

	return 0;
}
